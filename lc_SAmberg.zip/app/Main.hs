module Main where

import LCInterpreter

main :: IO ()
main = putStrLn "hello world"
